// File ignored in coverage tests via setting in .istanbul.yml
