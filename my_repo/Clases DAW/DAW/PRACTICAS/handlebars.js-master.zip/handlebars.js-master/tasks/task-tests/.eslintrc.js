module.exports = {
  extends: '../../.eslintrc.js',
  env: {
    mocha: true
  },
  parserOptions: {
    ecmaVersion: 2018
  }
};
